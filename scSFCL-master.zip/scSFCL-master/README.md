**scSFCL:Deep Clustering of scRNA-seq Data with Subspace Feature Confidence Learning**

# scSFCL:Deep Clustering of scRNA-seq Data with Subspace Feature Confidence Learning 




## Environment：

tensorflow == 2.13.0
numpy == 1.24.1
scanpy == 1.9.6
scikit-learn == 1.3.2
scipy == 1.10.1
pandas == 2.0.3
keras == 2.13.1
