import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.nn import Linear


def xavier_init(m):
    if type(m) == nn.Linear:
        nn.init.xavier_normal_(m.weight)
        if m.bias is not None:
           m.bias.data.fill_(0.0)

class LinearLayer(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.clf = nn.Sequential(nn.Linear(in_dim, out_dim))
        self.clf.apply(xavier_init)

    def forward(self, x):
        x = self.clf(x)
        return x


class MeanAct(nn.Module):
    def __init__(self):
        super(MeanAct, self).__init__()

    def forward(self, x):
        return torch.clamp(torch.exp(x), min=1e-5, max=1e6)

class DispAct(nn.Module):
    def __init__(self):
        super(DispAct, self).__init__()

    def forward(self, x):
        return torch.clamp(F.softplus(x), min=1e-4, max=1e4)

class zinb_VAE(nn.Module):
    def __init__(self, input_dim,n_enc_2,hidden_dim,
                           latent_dim):
        super(zinb_VAE, self).__init__()

        self.enc_1 = Linear(input_dim, n_enc_2)

        self.enc_3 = Linear(n_enc_2, hidden_dim)

        self.enc_mu = nn.Linear(hidden_dim, latent_dim)
        self.enc_var = nn.Linear(hidden_dim, latent_dim)

        self.dec_1 = Linear(latent_dim,n_enc_2)

        self.dec_mean = nn.Sequential(nn.Linear(n_enc_2, input_dim), MeanAct())
        self.dec_disp = nn.Sequential(nn.Linear(n_enc_2, input_dim), DispAct())
        self.dec_pi = nn.Sequential(nn.Linear(n_enc_2, input_dim), nn.Sigmoid())

    def encode(self, x):
        enc_h1 = F.relu(self.enc_1(x))
        h1 = F.relu(self.enc_3(enc_h1))
        return self.enc_mu(h1), self.enc_var(h1)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):
        h = F.relu(self.dec_1(z))
        mu = self.dec_mean(h)
        disp = self.dec_disp(h)
        pi = self.dec_pi(h)
        return mu, disp, pi

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        mu, disp, pi=self.decode(z)
        return mu, disp, pi , mu, logvar, z



class GraphConvolution(nn.Module):

    def __init__(self, in_features, out_features, residual=False, variant=False):
        super(GraphConvolution, self).__init__()
        self.variant = variant
        if self.variant:
            self.in_features = 2*in_features
        else:
            self.in_features = in_features

        self.out_features = out_features
        self.residual = residual #表示是否使用残差连接（Residual Connection)
        #可训练的权重矩阵 self.weight，其形状为 (输入特征维度, 输出特征维度)，并使用 Xavier 初始化方法对其进行初始化。
        self.weight = Parameter(torch.FloatTensor(self.in_features,self.out_features))
        #self.reset_parameters()
        torch.nn.init.xavier_uniform_(self.weight)

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.out_features)
        self.weight.data.uniform_(-stdv, stdv)

    def forward(self, input, adj , h0 , lamda, alpha, l):
        theta = math.log(lamda/l+1)
        hi = torch.spmm(adj, input)
        if self.variant:
            support = torch.cat([hi,h0],1)
            r = (1-alpha)*hi+alpha*h0
        else:
            support = (1-alpha)*hi+alpha*h0
            r = support
        output = theta*torch.mm(support, self.weight)+(1-theta)*r
        if self.residual:
            output = output+input
        return output

class GCNII(nn.Module):
    def __init__(self, nlayers,nhidden, nclass, dropout, lamda, alpha, variant):
        super(GCNII, self).__init__()
        # Define layers that are common across all input dimensions
        self.convs = nn.ModuleList()
        for _ in range(nlayers):
            self.convs.append(GraphConvolution(nhidden, nhidden,variant=variant, residual=False))


        # Define layers specific to each input dimension
        self.specific_layers = nn.ModuleDict()

        self.params1 = list(self.convs.parameters())
        self.params2 = list(self.specific_layers.parameters())

        self.act_fn = nn.ReLU()
        self.dropout = dropout
        self.alpha = alpha
        self.lamda = lamda
        self.nhidden =nhidden
        self.nclass =nclass


    def forward(self, x, input,adj):


        self.fcs = nn.ModuleList().to("cuda")#
        self.fcs.append(nn.Linear(input, self.nhidden)).to("cuda")  #
        self.fcs.append(nn.Linear(self.nhidden, self.nclass)).to("cuda")#

        _layers = []
        layer_inner = self.act_fn(self.fcs[0](x))
        _layers.append(layer_inner)
        #layer_inner = x
        #_layers.append(layer_inner)


        for i,con in enumerate(self.convs):
            layer_inner = self.act_fn(con(layer_inner,adj,_layers[0],self.lamda,self.alpha,i+1))
        layer_inner = self.fcs[-1](layer_inner)
        return F.softmax(layer_inner, dim=1)



