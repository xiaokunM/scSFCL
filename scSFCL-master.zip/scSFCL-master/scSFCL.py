import skfuzzy as fuzz
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from scSFCL_utils import LinearLayer, zinb_VAE, GCNII



class scSFCL (nn.Module):
    def __init__(self, args, n_enc_1, n_enc_2, n_enc_3, n_dec_1, n_dec_2, n_dec_3,
                 n_input, input_list, hidden_dim, n_z, n_clusters, dropout, v=1):
        super(scSFCL, self).__init__()
        #
        self.views = len(input_list)
        self.nclass = n_clusters
        self.dropout = dropout
        self.input_list = input_list
        self.hidden_dim = hidden_dim

        self.FeatureInforEncoder = nn.ModuleList(
            [LinearLayer(input_list[view], input_list[view]) for view in range(self.views)])

        self.fc_layer = nn.Linear(n_clusters * self.views, n_clusters)

        self.gcn_model = GCNII(
            nlayers=args.nlayers,
            nhidden=args.nhidden,
            nclass=n_clusters,
            dropout=0,
            lamda=0.3,
            alpha=0.2,
            variant=False)

        self.zinb_vae = zinb_VAE(input_dim=n_input,
                                 n_enc_2=n_enc_2,
                                 hidden_dim=args.nhidden,
                                 latent_dim=n_z)

        # cluster layer
        self.cluster_layer = Parameter(torch.Tensor(n_clusters, n_z))  # cluster_layer 是一个矩阵，形状为 (n_clusters, n_z)
        torch.nn.init.xavier_normal_(self.cluster_layer.data)  # 使用 Xavier 初始化方法来初始化 cluster_layer

        self.gcn_cluster_layer = Parameter(
            torch.Tensor(n_clusters, n_clusters))  # cluster_layer 是一个矩阵，形状为 (n_clusters, n_z)
        torch.nn.init.xavier_normal_(self.gcn_cluster_layer.data)  # 使用 Xavier 初始化方法来初始化 cluster_layer

        # 使用循环初始化每个视图的参数
        self.gcn_cluster_layers = dict()
        for view in range(self.views):
            param = nn.Parameter(torch.Tensor(n_clusters, n_clusters))
            torch.nn.init.xavier_normal_(param.data)
            self.gcn_cluster_layers[view] = param

        # degree
        self.v = v
        self.m = 2

    def add_noise(self, args, inputs):

        return inputs.to("cpu") + (torch.randn(inputs.shape) * args.noise_value)

    def forward(self, args, raw_data, data_list, adj):

        x_noise = self.add_noise(args, raw_data)
        x_noise = x_noise.to("cuda")
        mu, disp, pi, mu, logvar, z = self.zinb_vae(x_noise)


        FeatureInfo, feature, predict, q_dict = dict(), dict(), dict(), dict()

        for view in range(self.views):

            FeatureInfo[view] = torch.sigmoid(data_list[view])
            feature[view] = data_list[view] * FeatureInfo[view]
            predict[view] = self.gcn_model(feature[view], feature[view].size(1), adj)


        predict_list = list(predict.values())



        for view_q in range(self.views):
            for key, value in self.gcn_cluster_layers.items():
                self.gcn_cluster_layers[key] = value.to("cuda")

            q_dict[view_q] = 1.0 / (1.0 + torch.sum(
                torch.pow(predict_list[view_q].unsqueeze(1) - self.gcn_cluster_layers[view_q], 2), 2) / self.v)
            q_dict[view_q] = q_dict[view_q].pow((self.v + 1.0) / 2.0)
            q_dict[view_q] = (q_dict[view_q].t() / torch.sum(q_dict[view_q], 1)).t()

        concatenated_predict = torch.cat(predict_list, dim=1)
        pred = concatenated_predict

        cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(
            pred.cpu().detach().numpy().T, self.nclass, self.m, error=0.005, maxiter=1000, init=None)
        u_tensor = torch.tensor(u, dtype=torch.float32)  # 将NumPy数组转换为PyTorch张量
        normalized_pred = torch.nn.functional.softmax(u_tensor, dim=1)
        predict = F.softmax(normalized_pred.T, dim=1)

        # Dual Self-supervised Module
        q = 1.0 / (1.0 + torch.sum(torch.pow(z.unsqueeze(1) - self.cluster_layer, 2), 2) / self.v)
        q = q.pow((self.v + 1.0) / 2.0)
        q = (q.t() / torch.sum(q, 1)).t()


        return q, predict, q_dict, mu, disp, pi





