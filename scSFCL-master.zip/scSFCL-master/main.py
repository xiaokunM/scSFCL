from __future__ import print_function, division
import random
import time
import numpy as np
import torch
import torch.nn.functional as F
from torch.optim import Adam
import cfg
from scSFCL import scSFCL
from utils import ZINBLoss ,target_distribution , clustering
from preprocess import get_subdata,get_highly_dataset
from utils import eva


def train(net, optimizer, args, data_3000, data, raw_adj, y):
    max_Z_acc = 0
    max_Z_nmi = 0
    max_Z_ari = 0
    #best_score=0

    views = len(data)
    predict,gcn_centers = dict(),dict()

    with torch.no_grad():
        _, _, _,  _, _, z = net.zinb_vae(data_3000)

        for view in range(views):
            predict[view]=net.gcn_model(data[view], data[view].size(1), raw_adj)

        predict_list = list(predict.values())
        concatenated_predict = torch.cat(predict_list, dim=1)
        pred = concatenated_predict

        _, _, _, vae_centers = clustering(args,z, y)

        for view in range(views):
            _, _, _, gcn_centers[view] = clustering(args,predict_list[view], y)

        # initialize cluster centers
        net.cluster_layer.data = torch.tensor(vae_centers).to(device)
        for view in range(views):
            net.gcn_cluster_layers[view].data = torch.tensor(gcn_centers[view]).to(device)


    for epoch in range(args.train_epoch):

        torch.cuda.empty_cache()
        net.train()
        optimizer.zero_grad()
        start_time = time.time()

        q,predict,q_dict, mu, disp, pi = net(args,data_3000, data, raw_adj)

        q_lis = list(q_dict.values())
        q = q.data
        q_list = q_lis.copy()
        q_nor = (q.data+q_list[0].data+q_list[1].data+q_list[2].data+q_list[3].data)/5

        p = target_distribution(q_nor)
        p1 = target_distribution(q_list[0])
        p2 = target_distribution(q_list[1])
        p3 = target_distribution(q_list[2])
        p4 = target_distribution(q_list[3])

        res1 = q.data.cpu().numpy().argmax(1)
        res2 = predict.data.cpu().numpy().argmax(1)
        res3 = p.data.cpu().numpy().argmax(1)
        res4 = (q_list[0]+q_list[1]+q_list[2]+q_list[3]).data.cpu().numpy().argmax(1)

        Q_acc , Q_nmi , Q_ari = eva(y, res1, str(epoch) + 'Q', pp=False)
        Z_acc , Z_nmi , Z_ari = eva(y, res2, str(epoch) + 'Z', pp=False)
        P_acc , P_nmi , p_ari = eva(y, res3, str(epoch) + 'P', pp=False)
        acc, nmi, ari = eva(y, res4, str(epoch) + 'P', pp=False)

        if Z_acc >= max_Z_acc:
            max_Z_acc = Z_acc
            acc_Z_epoch = epoch
        if Z_nmi >= max_Z_nmi:
            max_Z_nmi = Z_nmi
            nmi_Z_epoch = epoch
        if Z_ari >= max_Z_ari:
            max_Z_ari = Z_ari
            ari_Z_epoch = epoch

        '''
        score = (Z_acc + Z_ari + Z_nmi) / 3
        
        if score >= best_score:
            best_score = score
            best_clusters = res2
            best_epoch = epoch
        '''

        if epoch % 500 <= 125:
            sub_loss = F.kl_div(q.log().to(device), p1, reduction='batchmean')

        elif  epoch % 500 <= 250:
            sub_loss = F.kl_div(q.log().to(device), p2, reduction='batchmean')

        elif epoch % 500 <= 375:
            sub_loss = F.kl_div(q.log().to(device), p3, reduction='batchmean')

        else:
            sub_loss = F.kl_div(q.log().to(device), p4, reduction='batchmean')

        kl_loss = F.kl_div(predict.to("cuda").log(), p, reduction='batchmean')
        ce_loss = F.kl_div(q.log().to("cuda"), p, reduction='batchmean')
        zinb_loss = ZINBLoss(data_3000, mu, disp, pi, 1)

        loss = args.kl_loss * kl_loss + args.ce_loss * ce_loss + args.zinb_loss * zinb_loss + args.sub_loss * sub_loss

        print(epoch, ':kl_loss {:.5f}'.format(kl_loss),':sub_loss {:.5f}'.format(sub_loss),
              ', ce_loss {:.5f}'.format(ce_loss),',  zinb_loss {:.5f}'.format( zinb_loss),
              ', total_loss {:.5f}'.format(loss))

        loss.backward()
        optimizer.step()

        end_time = time.time()  # 记录当前时间
        epoch_time = end_time - start_time  # 计算 epoch 的训练时间

        print(
            f"Epoch [{epoch + 1}/{args.train_epoch}] - Loss: {loss.item():.4f} - Epoch_Time: {epoch_time:.2f} seconds")


        print(epoch + 1, ':Q_acc {:.5f}'.format(Q_acc), ', Q_nmi {:.5f}'.format(Q_nmi),
              ', Q_ari {:.5f}'.format(Q_ari))
        print(epoch + 1, ':Z_acc {:.5f}'.format(Z_acc), ', Z_nmi {:.5f}'.format(Z_nmi),
              ', Z_ari {:.5f}'.format(Z_ari))
        print(epoch + 1, ':P_acc {:.5f}'.format(P_acc), ', P_nmi {:.5f}'.format(P_nmi),
              ', p_ari {:.5f}'.format(p_ari))
        print(epoch + 1, ':acc {:.5f}'.format(acc), ', nmi {:.5f}'.format(nmi),
              ', ari {:.5f}'.format(ari))

    print(args)
    print('----------MAX----------')

    print(acc_Z_epoch, ':max_Z_acc {:.5f}'.format(max_Z_acc))
    print(nmi_Z_epoch, ':max_Z_nmi {:.5f}'.format(max_Z_nmi))
    print(ari_Z_epoch, ':max_Z_ari {:.5f}'.format(max_Z_ari))


if __name__ == "__main__":

    torch.autograd.set_detect_anomaly(True)
    seed = 666
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)

    args = cfg.parse_args()
    device = torch.device('cuda')

    data_list, adj, y, gene_name = get_subdata(args, device)

    highly_data = get_highly_dataset(args)
    data_3000 = torch.tensor(highly_data).to(device).to(torch.float32)

    net = scSFCL(args, 512, 256, 64, 64, 256, 512,
                     n_input=3000,
                     input_list=args.input_list,
                     hidden_dim=args.nhidden,
                     n_z=args.n_z,
                     n_clusters=args.n_clusters,
                     dropout=0.5,
                     v=1.0).to(device)

    optimizer = Adam(net.parameters(), lr=args.lr)

    train(net, optimizer, args, data_3000, data_list, adj, y)

